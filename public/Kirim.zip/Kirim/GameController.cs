using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor.SearchService;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public GameScene currentScene;
    public BubbleController bubble;
    public BackgroundController backgroundController;
    private State state= State.IDLE;
    public AudioController audioController;
    private enum State{
        IDLE, ANIMATE, END
    }
    // Start is called before the first frame update
    void Start()
    {
        if (currentScene is StoryScene)
        {
            StoryScene storyScene = currentScene as StoryScene;
            bubble.PlayScene(storyScene);
            backgroundController.SetImage(storyScene.background);
            PlayAudio(storyScene.sentences[0]);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0))
        {
            if (state == State.IDLE && bubble.IsCompleted())
            {
                if (bubble.IsLastSentence() && (currentScene as StoryScene).nextScene != null)
                {
                    PlayScene((currentScene as StoryScene).nextScene);
                }
                else if((currentScene as StoryScene).nextScene == null){
                    SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
                }
                else
                {
                    bubble.PlayNextSentence();
                    PlayAudio((currentScene as StoryScene)
                        .sentences[bubble.GetSentenceIndex()]);
                }
            } 
        }
    }

    private void PlayScene(GameScene scene){
        StartCoroutine(SwitchScene(scene));
    }

    private IEnumerator SwitchScene(GameScene scene){
        state = State.ANIMATE;
        currentScene = scene;
        bubble.Hide();
        yield return new WaitForSeconds(1f);
        StoryScene storyScene = scene as StoryScene;
        if(storyScene.background != null){
            backgroundController.SwitchImage(storyScene.background);
            PlayAudio(storyScene.sentences[0]);
            yield return new WaitForSeconds(1f);
            bubble.ClearText();
            bubble.Show();
            yield return new WaitForSeconds(1f);
            bubble.PlayScene(storyScene);
            state = State.IDLE;
        } else{
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
    }

    private void PlayAudio(StoryScene.Sentence sentence)
    {
        audioController.PlayAudio(sentence.music, sentence.sound);
    }
}
